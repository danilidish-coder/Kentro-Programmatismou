package main
import "fmt"
func main(){fmt.Println("KENTRO_SMOKE_OK")}
