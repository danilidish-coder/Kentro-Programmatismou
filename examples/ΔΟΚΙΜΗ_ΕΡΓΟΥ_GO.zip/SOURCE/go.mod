module kentro.example/demo

go 1.23
