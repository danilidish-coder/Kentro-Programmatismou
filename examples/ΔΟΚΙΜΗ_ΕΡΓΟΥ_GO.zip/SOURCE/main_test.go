package main
import ("sync";"testing")
func TestSimple(t *testing.T){if 5+7!=12 {t.Fatal("arithmetic")}}
func TestConcurrent(t *testing.T){var wg sync.WaitGroup;var mu sync.Mutex;n:=0;for i:=0;i<8;i++{wg.Add(1);go func(){defer wg.Done();for j:=0;j<100;j++{mu.Lock();n++;mu.Unlock()}}()};wg.Wait();if n!=800{t.Fatalf("%d",n)}}
